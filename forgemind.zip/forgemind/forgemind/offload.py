"""Smart offloading: (1) gradients + optimizer states -> CPU, (2) saved activations -> CPU, (3) MoE experts -> CPU (see moe.py)."""
from __future__ import annotations
import torch
import torch.nn as nn
from .config import OffloadConfig


def _gpu_pressure() -> float:
    if not torch.cuda.is_available():
        return 0.0
    free, total = torch.cuda.mem_get_info()
    return 1.0 - free / total


class OffloadedAdamW:
    """AdamW whose fp32 master weights and moments live in (pinned) CPU RAM.
    Gradients are streamed GPU->CPU on a side stream the moment they are produced (post-accumulate hook), so the GPU never
    holds more than a few live grads. "Smart" policy: tiny tensors stay put (one big copy later beats many tiny ones) and,
    with gpu_watermark>0, nothing is streamed until GPU memory use crosses the watermark.
    Works for single-GPU and DDP (call .collect() after backward when hooks are off). Not for FSDP (use CPUOffloadPolicy)."""

    def __init__(self, param_groups, lr, betas=(0.9, 0.95), eps=1e-8, cfg: OffloadConfig = None, overlap=True):
        self.cfg = cfg or OffloadConfig()
        self.params = [p for g in param_groups for p in g["params"]]
        assert not any(hasattr(p, "to_local") for p in self.params), "OffloadedAdamW does not support DTensor/FSDP params"
        self.cuda = any(p.is_cuda for p in self.params)
        self.stream = torch.cuda.Stream() if self.cuda else None
        self.pending = []
        self.master, self.cgrad = {}, {}
        groups = []
        for g in param_groups:
            ms = []
            for p in g["params"]:
                m = p.detach().to("cpu", torch.float32, copy=True)
                cg = torch.zeros_like(m)
                if self.cuda:
                    m, cg = m.pin_memory(), cg.pin_memory()
                m.grad = cg
                self.master[p], self.cgrad[p] = m, cg
                ms.append(m)
            groups.append({**{k: v for k, v in g.items() if k != "params"}, "params": ms})
        self.opt = torch.optim.AdamW(groups, lr=lr, betas=betas, eps=eps)
        self.param_groups = self.opt.param_groups
        self.hooks = []
        if overlap:
            for p in self.params:
                self.hooks.append(p.register_post_accumulate_grad_hook(self._hook))

    # -- grad streaming ----------------------------------------------------------------------------------------------
    def _eligible(self, p):
        if not self.cfg.smart:
            return True
        if p.numel() < self.cfg.min_numel:
            return False
        return self.cfg.gpu_watermark <= 0 or _gpu_pressure() >= self.cfg.gpu_watermark

    def _hook(self, p):
        if p.grad is not None and self._eligible(p):
            self._offload(p)

    def _offload(self, p):
        g = p.grad
        if self.cuda and g.is_cuda:
            self.stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(self.stream):
                tmp = torch.empty(g.shape, dtype=g.dtype, device="cpu", pin_memory=True)
                tmp.copy_(g, non_blocking=True)
            g.record_stream(self.stream)
            self.pending.append((p, tmp))
        else:
            self.cgrad[p].add_(g.detach().to("cpu", torch.float32))
        p.grad = None

    def collect(self):
        """move every remaining grad off the device (call after each micro-batch backward)"""
        for p in self.params:
            if p.grad is not None:
                self._offload(p)
        self.flush()

    def flush(self):
        if self.pending:
            self.stream.synchronize()
            for p, tmp in self.pending:
                self.cgrad[p].add_(tmp)
            self.pending.clear()

    # -- optimizer API -----------------------------------------------------------------------------------------------
    @torch.no_grad()
    def clip_grad_norm_(self, max_norm):
        self.collect()
        gs = list(self.cgrad.values())
        norm = torch.linalg.vector_norm(torch.stack(torch._foreach_norm(gs)))
        if max_norm and max_norm > 0:
            coef = torch.clamp(max_norm / (norm + 1e-6), max=1.0)
            torch._foreach_mul_(gs, coef)
        return norm

    @torch.no_grad()
    def step(self):
        self.collect()
        self.opt.step()
        for p in self.params:
            p.data.copy_(self.master[p], non_blocking=self.cuda)
        if self.cuda:
            torch.cuda.current_stream().synchronize()
        torch._foreach_zero_(list(self.cgrad.values()))

    def zero_grad(self, set_to_none=True):
        for p in self.params:
            p.grad = None
        self.pending.clear()
        torch._foreach_zero_(list(self.cgrad.values()))

    def state_dict(self):
        return {"opt": self.opt.state_dict(), "master": [self.master[p] for p in self.params]}

    def load_state_dict(self, sd):
        self.opt.load_state_dict(sd["opt"])
        for p, m in zip(self.params, sd["master"]):
            self.master[p].copy_(m)
            p.data.copy_(m)


class ActivationOffload(torch.autograd.graph.saved_tensors_hooks):
    """Spill big saved-for-backward CUDA activations to pinned host memory; weights and small tensors stay on device."""

    def __init__(self, min_bytes=1 << 20):
        pin = torch.cuda.is_available()

        def pack(t):
            if (not t.is_cuda or t.numel() * t.element_size() < min_bytes
                    or isinstance(t, nn.Parameter) or (t.requires_grad and t.is_leaf)):
                return (None, t)
            buf = torch.empty(t.shape, dtype=t.dtype, device="cpu", pin_memory=pin)
            buf.copy_(t, non_blocking=True)   # same-stream ordered: safe to free t afterwards
            return (t.device, buf)

        def unpack(x):
            dev, buf = x
            return buf if dev is None else buf.to(dev, non_blocking=True)

        super().__init__(pack, unpack)


def apply_activation_offload(model, cfg: OffloadConfig):
    blocks = list(model.layers.values())
    n = max(1, int(len(blocks) * cfg.act_layers)) if blocks else 0
    for b in blocks[:n]:
        orig = b.forward

        def fwd(*a, _o=orig, **k):
            with ActivationOffload(cfg.act_min_bytes):
                return _o(*a, **k)
        b.forward = fwd
    return model
