import math
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, Sampler


class SyntheticLM(Dataset):
    """deterministic learnable toy data: repeating motifs -> loss must go down fast (used by tests/examples)"""
    def __init__(self, vocab, seq, n=4096, seed=0):
        g = torch.Generator().manual_seed(seed)
        self.motifs = torch.randint(0, vocab, (16, 8), generator=g)
        self.pick = torch.randint(0, 16, (n, seq // 8 + 2), generator=g)
        self.seq = seq

    def __len__(self):
        return len(self.pick)

    def __getitem__(self, i):
        t = self.motifs[self.pick[i]].flatten()[: self.seq + 1]
        return {"input_ids": t[:-1].clone(), "labels": t[1:].clone()}


class TokenFile(Dataset):
    """flat uint16/uint32 token file (np.memmap), fixed-length windows"""
    def __init__(self, path, seq, dtype="uint16"):
        self.data = np.memmap(path, dtype=dtype, mode="r")
        self.seq = seq
        self.n = (len(self.data) - 1) // seq

    def __len__(self):
        return self.n

    def __getitem__(self, i):
        x = torch.from_numpy(self.data[i * self.seq:(i + 1) * self.seq + 1].astype(np.int64))
        return {"input_ids": x[:-1], "labels": x[1:]}


class ResumableSampler(Sampler):
    """shards by *data-parallel* rank (so tp/pp ranks of one replica see identical data) and can resume mid-epoch"""
    def __init__(self, n, dp_rank, dp_world, seed=0, shuffle=True):
        self.n, self.r, self.w, self.seed, self.shuffle = n, dp_rank, dp_world, seed, shuffle
        self.epoch, self.skip = 0, 0

    def __iter__(self):
        g = torch.Generator().manual_seed(self.seed + self.epoch)
        idx = torch.randperm(self.n, generator=g).tolist() if self.shuffle else list(range(self.n))
        idx = idx[: self.n - self.n % self.w][self.r::self.w]
        idx = idx[self.skip:]
        self.skip = 0
        return iter(idx)

    def __len__(self):
        return (self.n // self.w) - self.skip


def build_loader(ds, micro_batch, ctx, seed=0, workers=0):
    s = ResumableSampler(len(ds), ctx.dp_rank, ctx.dp_world, seed)
    dl = DataLoader(ds, batch_size=micro_batch, sampler=s, drop_last=True, num_workers=workers,
                    pin_memory=ctx.device.type == "cuda")
    return dl, s
