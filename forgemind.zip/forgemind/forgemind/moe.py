"""Mixture-of-Experts: top-k router, dropless sorted dispatch, expert parallelism (all-to-all),
optional CPU expert offload (stream only the experts that received tokens, Unsloth-style)."""
from __future__ import annotations
import math
from typing import List, Optional
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist


class _A2A(torch.autograd.Function):
    """differentiable all_to_all_single with uneven splits"""
    @staticmethod
    def forward(ctx, x, out_splits, in_splits, group):
        ctx.out_splits, ctx.in_splits, ctx.group = out_splits, in_splits, group
        out = x.new_empty((sum(out_splits),) + tuple(x.shape[1:]))
        dist.all_to_all_single(out, x.contiguous(), out_splits, in_splits, group=group)
        return out

    @staticmethod
    def backward(ctx, g):
        gi = g.new_empty((sum(ctx.in_splits),) + tuple(g.shape[1:]))
        dist.all_to_all_single(gi, g.contiguous(), ctx.in_splits, ctx.out_splits, group=ctx.group)
        return gi, None, None, None


class Router(nn.Module):
    def __init__(self, dim, n_experts, top_k):
        super().__init__()
        self.gate = nn.Linear(dim, n_experts, bias=False)
        self.n_experts, self.top_k = n_experts, top_k

    def forward(self, x):  # x [N, d]
        logits = self.gate(x).float()
        probs = logits.softmax(-1)
        w, idx = probs.topk(self.top_k, dim=-1)
        w = w / w.sum(-1, keepdim=True)
        E = self.n_experts
        with torch.no_grad():
            frac = torch.bincount(idx.flatten(), minlength=E).float() / idx.numel()
        aux = E * (frac * probs.mean(0)).sum()                # switch-style load balance
        z = logits.logsumexp(-1).pow(2).mean()                # router z-loss
        return w.to(x.dtype), idx, aux, z


class Experts(nn.Module):
    """SwiGLU experts. stacked=[E,d,h] params (fast) or per-expert params (needed for CPU offload)."""

    def __init__(self, n_local, dim, hidden, offload=False, grouped_mm=False):
        super().__init__()
        self.n_local, self.offload, self.grouped_mm = n_local, offload, grouped_mm
        if offload:
            mk = lambda a, b: nn.ParameterList([nn.Parameter(torch.empty(a, b)) for _ in range(n_local)])
        else:
            mk = lambda a, b: nn.Parameter(torch.empty(n_local, a, b))
        self.w1, self.w3, self.w2 = mk(dim, hidden), mk(dim, hidden), mk(hidden, dim)
        self.reset_parameters(dim, hidden)

    def reset_parameters(self, dim, hidden):
        def init(p, fan_in):
            nn.init.normal_(p, std=0.02)
        for w in (self.w1, self.w3, self.w2):
            for p in (w if self.offload else [w]):
                init(p.data if hasattr(p, "data") else p, 0)
        if self.offload:  # pinned host memory so H2D copies are async
            if torch.cuda.is_available():
                for w in (self.w1, self.w3, self.w2):
                    for p in w:
                        p.data = p.data.pin_memory()

    def _w(self, name, e, device):
        w = getattr(self, name)
        t = w[e] if self.offload else w[e]
        if self.offload and t.device != device:
            t = t.to(device, non_blocking=True)  # autograd: grad flows back to the CPU param
        return t

    def forward(self, x, counts: List[int]):
        # x: tokens sorted by local expert; counts: python ints per local expert
        if self.grouped_mm and not self.offload and x.is_cuda and hasattr(torch, "_grouped_mm") and x.dtype == torch.bfloat16:
            try:
                offs = torch.tensor(counts, device=x.device).cumsum(0).to(torch.int32)
                h = F.silu(torch._grouped_mm(x, self.w1.to(x.dtype), offs=offs)) * torch._grouped_mm(x, self.w3.to(x.dtype), offs=offs)
                return torch._grouped_mm(h, self.w2.to(x.dtype), offs=offs)
            except Exception:
                pass
        outs, start = [], 0
        for e, c in enumerate(counts):
            if c == 0:
                continue  # offload: inactive experts never leave host memory
            xe = x[start:start + c]
            start += c
            w1, w3, w2 = (self._w(n, e, x.device) for n in ("w1", "w3", "w2"))
            outs.append((F.silu(xe @ w1.to(xe.dtype)) * (xe @ w3.to(xe.dtype))) @ w2.to(xe.dtype))
        if not outs:  # keep graph connected when a rank received nothing
            return x.sum() * 0 + x[:0]
        return torch.cat(outs, 0)


class MoE(nn.Module):
    def __init__(self, dim, hidden, n_experts, top_k, n_shared=0, ep_size=1, ep_group=None, ep_rank=0,
                 offload_experts=False, grouped_mm=False, aux_coef=1e-2, z_coef=1e-3):
        super().__init__()
        assert n_experts % ep_size == 0
        self.dim, self.n_experts, self.top_k = dim, n_experts, top_k
        self.ep_size, self.ep_group, self.ep_rank = ep_size, ep_group, ep_rank
        self.n_local = n_experts // ep_size
        self.router = Router(dim, n_experts, top_k)
        self.experts = Experts(self.n_local, dim, hidden, offload=offload_experts, grouped_mm=grouped_mm)
        self.shared = None
        if n_shared:
            from .models.gpt import SwiGLU
            self.shared = SwiGLU(dim, hidden * n_shared)
        self.aux_coef, self.z_coef = aux_coef, z_coef
        self.last_aux: Optional[torch.Tensor] = None

    def forward(self, x):
        shp = x.shape
        x = x.reshape(-1, self.dim)
        N = x.size(0)
        w, idx, aux, z = self.router(x)
        self.last_aux = self.aux_coef * aux + self.z_coef * z
        flat = idx.flatten()
        order = flat.argsort(stable=True)
        tok = order // self.top_k
        xs = x[tok]
        counts = torch.bincount(flat, minlength=self.n_experts)

        if self.ep_size == 1:
            ys = self.experts(xs, counts.tolist())
        else:
            E_l, ep = self.n_local, self.ep_size
            cmat = counts.view(ep, E_l)
            send = cmat.sum(1).tolist()
            recv_mat = torch.empty_like(cmat)
            dist.all_to_all_single(recv_mat.view(-1), cmat.contiguous().view(-1), group=self.ep_group)
            R = recv_mat.tolist()                           # R[src][e] tokens from src for my local expert e
            recv = [sum(r) for r in R]
            xr = _A2A.apply(xs, recv, send, self.ep_group)  # layout: [src][e]
            starts, off = [], 0
            seg = [[None] * E_l for _ in range(ep)]
            for r in range(ep):
                for e in range(E_l):
                    seg[r][e] = (off, R[r][e])
                    off += R[r][e]
            per_e_in = [torch.cat([xr[a:a + c] for a, c in (seg[r][e] for r in range(ep))], 0) for e in range(E_l)]
            per_e_out = []
            for e in range(E_l):
                c = sum(R[r][e] for r in range(ep))
                per_e_out.append(self.experts(per_e_in[e], [c if i == e else 0 for i in range(E_l)]) if c else per_e_in[e])
            pieces = [[None] * E_l for _ in range(ep)]
            for e in range(E_l):
                parts = per_e_out[e].split([R[r][e] for r in range(ep)], 0)
                for r in range(ep):
                    pieces[r][e] = parts[r]
            yr = torch.cat([pieces[r][e] for r in range(ep) for e in range(E_l)], 0)
            ys = _A2A.apply(yr, send, recv, self.ep_group)  # back to original sorted order

        ys = ys * w.flatten()[order].unsqueeze(-1)
        out = torch.zeros_like(x).index_add_(0, tok, ys.to(x.dtype))
        if self.shared is not None:
            out = out + self.shared(x)
        return out.view(shp)
