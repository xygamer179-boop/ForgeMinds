import torch
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint


def chunked_cross_entropy(h, weight, labels, chunk=4096, ignore_index=-100):
    """CE over lm_head(h) without ever materialising the full [N, vocab] logits (each chunk is recomputed in backward)."""
    h = h.reshape(-1, h.size(-1))
    y = labels.reshape(-1)
    n = (y != ignore_index).sum().clamp(min=1)

    def f(hc, yc):
        return F.cross_entropy((hc @ weight.t().to(hc.dtype)).float(), yc, ignore_index=ignore_index, reduction="sum")

    total = h.new_zeros((), dtype=torch.float32)
    for i in range(0, h.size(0), chunk):
        total = total + checkpoint(f, h[i:i + chunk], y[i:i + chunk], use_reentrant=False)
    return total / n


def logits_cross_entropy(logits, labels, ignore_index=-100):
    return F.cross_entropy(logits.reshape(-1, logits.size(-1)).float(), labels.reshape(-1), ignore_index=ignore_index)
