"""Reference decoder-only transformer (RMSNorm, RoPE, GQA, SwiGLU, optional MoE). Everything ForgeMind needs from a model
is: `.layers` (ModuleDict of blocks), optional `tok_emb`/`norm`/`lm_head`, `.aux_loss()`, `.split_stage()`, `.tp_plan()`."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import torch
import torch.nn as nn
import torch.nn.functional as F
from ..loss import chunked_cross_entropy


@dataclass
class GPTConfig:
    vocab_size: int = 32000
    dim: int = 512
    n_layers: int = 8
    n_heads: int = 8
    n_kv_heads: int = 4
    ffn_mult: float = 8 / 3
    max_seq: int = 2048
    rope_theta: float = 10000.0
    tie_embeddings: bool = False
    loss_chunk: int = 4096
    # MoE
    n_experts: int = 0          # 0 = dense
    top_k: int = 2
    moe_every: int = 1          # every k-th layer is MoE
    n_shared_experts: int = 0
    expert_hidden_mult: float = 1.0   # expert hidden = ffn_hidden * mult
    aux_coef: float = 1e-2
    z_coef: float = 1e-3
    mixer: str = "attn"       # "attn" | "cell" (GatedCell recurrent mixer, O(T) time, no KV cache)


class RMSNorm(nn.Module):
    def __init__(self, dim, eps=1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x):
        return F.rms_norm(x, (x.size(-1),), self.weight.to(x.dtype), self.eps)


def rope_cache(T, hd, theta, device):
    inv = 1.0 / (theta ** (torch.arange(0, hd, 2, device=device).float() / hd))
    f = torch.outer(torch.arange(T, device=device).float(), inv)
    return f.cos(), f.sin()


def apply_rope(x, cos, sin):  # x [B,T,H,hd]
    x1, x2 = x.float().chunk(2, -1)
    c, s = cos[None, :, None, :], sin[None, :, None, :]
    return torch.cat([x1 * c - x2 * s, x1 * s + x2 * c], -1).type_as(x)


class Attention(nn.Module):
    def __init__(self, c: GPTConfig):
        super().__init__()
        self.hd = c.dim // c.n_heads
        self.theta = c.rope_theta
        self.wq = nn.Linear(c.dim, c.n_heads * self.hd, bias=False)
        self.wk = nn.Linear(c.dim, c.n_kv_heads * self.hd, bias=False)
        self.wv = nn.Linear(c.dim, c.n_kv_heads * self.hd, bias=False)
        self.wo = nn.Linear(c.n_heads * self.hd, c.dim, bias=False)

    def forward(self, x):
        B, T, _ = x.shape
        q = self.wq(x).view(B, T, -1, self.hd)   # -1: local head count under tensor parallelism
        k = self.wk(x).view(B, T, -1, self.hd)
        v = self.wv(x).view(B, T, -1, self.hd)
        cos, sin = rope_cache(T, self.hd, self.theta, x.device)
        q, k = apply_rope(q, cos, sin), apply_rope(k, cos, sin)
        q, k, v = (t.transpose(1, 2) for t in (q, k, v))
        o = F.scaled_dot_product_attention(q, k, v, is_causal=True, enable_gqa=q.size(1) != k.size(1))
        return self.wo(o.transpose(1, 2).reshape(B, T, -1))


class SwiGLU(nn.Module):
    def __init__(self, dim, hidden):
        super().__init__()
        self.w1 = nn.Linear(dim, hidden, bias=False)
        self.w3 = nn.Linear(dim, hidden, bias=False)
        self.w2 = nn.Linear(hidden, dim, bias=False)

    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class Block(nn.Module):
    def __init__(self, c: GPTConfig, layer_id: int, moe_kwargs: Optional[dict] = None):
        super().__init__()
        self.attn_norm, self.ffn_norm = RMSNorm(c.dim), RMSNorm(c.dim)
        if c.mixer == "cell":
            from .cell import CellMixer
            self.attn = CellMixer(c.dim)
        else:
            self.attn = Attention(c)
        hidden = int(c.dim * c.ffn_mult)
        hidden = (hidden + 63) // 64 * 64
        self.is_moe = c.n_experts > 0 and layer_id % c.moe_every == 0
        if self.is_moe:
            from ..moe import MoE
            mk = dict(moe_kwargs or {})
            self.ffn = MoE(c.dim, (int(hidden * c.expert_hidden_mult) + 63) // 64 * 64, c.n_experts, c.top_k,
                           n_shared=c.n_shared_experts, aux_coef=c.aux_coef, z_coef=c.z_coef, **mk)
        else:
            self.ffn = SwiGLU(c.dim, hidden)

    def forward(self, x):
        x = x + self.attn(self.attn_norm(x))
        return x + self.ffn(self.ffn_norm(x))


class GPT(nn.Module):
    def __init__(self, c: GPTConfig, moe_kwargs: Optional[dict] = None):
        super().__init__()
        self.cfg = c
        self.tok_emb = nn.Embedding(c.vocab_size, c.dim)
        self.layers = nn.ModuleDict({str(i): Block(c, i, moe_kwargs) for i in range(c.n_layers)})
        self.norm = RMSNorm(c.dim)
        self.lm_head = nn.Linear(c.dim, c.vocab_size, bias=False)
        if c.tie_embeddings:
            self.lm_head.weight = self.tok_emb.weight
        self.apply(self._init)
        for n, p in self.named_parameters():
            if n.endswith(("wo.weight", "w2.weight")):
                nn.init.normal_(p, std=0.02 / (2 * c.n_layers) ** 0.5)

    @staticmethod
    def _init(m):
        if isinstance(m, (nn.Linear, nn.Embedding)):
            nn.init.normal_(m.weight, std=0.02)

    def forward(self, tokens, labels=None):
        h = self.tok_emb(tokens) if self.tok_emb is not None else tokens
        for blk in self.layers.values():
            h = blk(h)
        if self.lm_head is None:         # non-final pipeline stage
            return h
        h = self.norm(h)
        if labels is None:
            return self.lm_head(h)
        return chunked_cross_entropy(h, self.lm_head.weight, labels, self.cfg.loss_chunk), self.aux_loss()

    def aux_loss(self):
        a = [b.ffn.last_aux for b in self.layers.values() if b.is_moe and b.ffn.last_aux is not None]
        return torch.stack(a).sum() if a else torch.zeros((), device=self.norm.weight.device if self.norm is not None else "cpu")

    def num_params(self, active_only=False):
        n = 0
        for name, p in self.named_parameters():
            if active_only and ".experts." in name:
                n += p.numel() * self.cfg.top_k // self.cfg.n_experts
            else:
                n += p.numel()
        return n

    def flops_per_token(self, seq):
        c = self.cfg
        return 6 * self.num_params(active_only=True) + 12 * c.n_layers * c.dim * seq

    # ---- hooks used by ForgeMind -------------------------------------------------------------------------------
    def tp_plan(self):
        return {"attn.wq": "col", "attn.wk": "col", "attn.wv": "col", "attn.wo": "row",
                "ffn.w1": "col", "ffn.w3": "col", "ffn.w2": "row"}   # dense FFN only; MoE experts are not TP'd

    def split_stage(self, stage: int, n_stages: int):
        """keep only this pipeline stage's layers (FQNs are preserved because layers is a ModuleDict)"""
        n = self.cfg.n_layers
        per = [n // n_stages + (1 if i < n % n_stages else 0) for i in range(n_stages)]
        lo = sum(per[:stage]); hi = lo + per[stage]
        for k in list(self.layers.keys()):
            if not lo <= int(k) < hi:
                del self.layers[k]
        if stage != 0:
            self.tok_emb = None
        if stage != n_stages - 1:
            self.norm = None
            self.lm_head = None
        return self
