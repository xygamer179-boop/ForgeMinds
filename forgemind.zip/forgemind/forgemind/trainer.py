from __future__ import annotations
import contextlib
import json
import math
import os
import shutil
import time
from typing import Callable, Optional
import torch
import torch.nn as nn
import torch.distributed as dist
from torch.utils.data import Dataset

from .config import ForgeConfig
from .distributed import init_distributed, DistContext, log
from .data import build_loader
from .loss import logits_cross_entropy
from .offload import OffloadedAdamW, apply_activation_offload
from .quant import quantize_model, make_optimizer_8bit, QuantState
from .parallel import native
from .parallel.ac import apply_activation_checkpointing
from .parallel.pipeline import PipelineRunner


class _Both:
    def __init__(self, *cms): self.cms = cms
    def __enter__(self):
        for c in self.cms: c.__enter__()
    def __exit__(self, *a):
        for c in reversed(self.cms): c.__exit__(*a)


def moe_kwargs(ctx: DistContext, cfg: ForgeConfig) -> dict:
    """kwargs for GPT(cfg, moe_kwargs=...) wiring expert parallelism / expert offload / grouped GEMM"""
    return dict(ep_size=ctx.pc.ep, ep_group=ctx.ep_group, ep_rank=ctx.ep_rank, offload_experts=cfg.offload.experts)


class Trainer:
    def __init__(self, model_fn: Callable[[DistContext], nn.Module], cfg: ForgeConfig, train_ds: Dataset,
                 eval_ds: Optional[Dataset] = None, micro_batch: int = 8, callbacks=(), peak_flops: Optional[float] = None):
        self.cfg, tc, pc, oc = cfg, cfg.train, cfg.parallel, cfg.offload
        self.ctx = ctx = init_distributed(pc)
        self.micro_batch, self.callbacks, self.peak_flops = micro_batch, list(callbacks), peak_flops
        self.use_ds = pc.backend == "deepspeed"
        torch.manual_seed(tc.seed)
        model = model_fn(ctx)
        self.raw = model
        self.seq = getattr(getattr(model, "cfg", None), "max_seq", None)

        if pc.ep > 1:  # different expert weights per ep rank
            g = torch.Generator().manual_seed(tc.seed + 1 + ctx.ep_rank)
            for n, p in model.named_parameters():
                if ".experts." in n:
                    p.data.normal_(0, 0.02, generator=g)
        if pc.pp > 1:
            model.split_stage(ctx.pp_rank, pc.pp)
            if getattr(model.cfg, "aux_coef", 0) and model.cfg.n_experts:
                log(ctx, "[forgemind] WARNING: MoE aux loss is not propagated across pipeline stages")
        model.to(ctx.device)

        # ---- ordering: quant -> TP -> AC / act-offload -> compile -> DP wrapper -> pipeline stage
        self.quant: QuantState = quantize_model(model, cfg.quant, ctx.dp_group)
        if pc.tp > 1:
            native.apply_tp(model, ctx)
        if tc.ac != "none":
            apply_activation_checkpointing(model, tc.ac)
        if oc.activations and ctx.device.type == "cuda":
            apply_activation_offload(model, oc)
        if tc.compile:
            for b in model.layers.values():   # MoE has data-dependent shapes: compile attention only there
                (b.attn if b.is_moe else b).compile()
        self.model = model
        if not self.use_ds:
            dp = ctx.dp_world > 1
            if dp and pc.dp_shard > 1:
                self.model = native.apply_fsdp(model, ctx, tc.bf16, pc.fsdp_cpu_offload, pc.fsdp_reshard_after_forward)
            elif dp and pc.dp_replicate > 1:
                self.model = native.apply_ddp(model, ctx)
        self.is_ddp = isinstance(self.model, nn.parallel.DistributedDataParallel)
        self.is_fsdp = hasattr(self.model, "set_requires_gradient_sync") and not self.is_ddp

        # ---- optimizer
        decay = [p for p in self.model.parameters() if p.requires_grad and p.ndim >= 2]
        nodecay = [p for p in self.model.parameters() if p.requires_grad and p.ndim < 2]
        groups = [{"params": decay, "weight_decay": tc.weight_decay}, {"params": nodecay, "weight_decay": 0.0}]
        self.off_opt = None
        if self.use_ds:
            from .parallel.deepspeed_backend import init_deepspeed
            self.engine, self.opt = init_deepspeed(self.model, groups, cfg, ctx.world, micro_batch)
        elif oc.optimizer:
            assert pc.pp == 1, "optimizer offload + pipeline not supported"
            overlap = not (self.is_ddp or self.is_fsdp)
            self.opt = self.off_opt = OffloadedAdamW(groups, tc.lr, tc.betas, tc.eps, oc, overlap=overlap)
            self.off_overlap = overlap
        elif cfg.quant.optimizer_8bit:
            self.opt = make_optimizer_8bit(groups, tc.lr, tc.betas, tc.eps)
        else:
            self.opt = torch.optim.AdamW(groups, lr=tc.lr, betas=tc.betas, eps=tc.eps, fused=ctx.device.type == "cuda")

        # ---- data
        self.train_dl, self.sampler = build_loader(train_ds, micro_batch, ctx, tc.seed)
        self.eval_dl = build_loader(eval_ds, micro_batch, ctx, tc.seed)[0] if eval_ds is not None else None
        self._it = iter(self.train_dl)
        self.epoch, self.batches_in_epoch = 0, 0

        # ---- pipeline
        self.pp = None
        if pc.pp > 1:
            assert micro_batch % pc.pp_microbatches == 0, "micro_batch must be divisible by pp_microbatches"
            self.pp = PipelineRunner(self.model, ctx, logits_cross_entropy, pc.pp_microbatches, pc.pp_schedule,
                                     fwd_ctx=lambda: _Both(self._autocast(), self.quant.autocast()))

        self.step, self.loss_ema, self.history = 0, None, []
        self.skipped = 0
        n = sum(p.numel() for p in self.raw.parameters())
        log(ctx, f"[forgemind] world={ctx.world} mesh(pp,dp_rep,dp_shard,tp)=({pc.pp},{pc.dp_replicate},{pc.dp_shard},{pc.tp}) ep={pc.ep} "
                 f"backend={pc.backend} quant={cfg.quant.mode}/{self.quant.backend} params(local)={n/1e6:.1f}M device={ctx.device}")
        if tc.resume:
            self.maybe_resume()

    # ------------------------------------------------------------------------------------------------ helpers
    def lr_at(self, step):
        tc = self.cfg.train
        if step < tc.warmup_steps:
            return tc.lr * (step + 1) / tc.warmup_steps
        prog = min(1.0, (step - tc.warmup_steps) / max(1, tc.max_steps - tc.warmup_steps))
        return tc.lr * (tc.min_lr_ratio + (1 - tc.min_lr_ratio) * 0.5 * (1 + math.cos(math.pi * prog)))

    def _next_batch(self):
        try:
            b = next(self._it)
        except StopIteration:
            self.epoch += 1
            self.batches_in_epoch = 0
            self.sampler.epoch = self.epoch
            self._it = iter(self.train_dl)
            b = next(self._it)
        self.batches_in_epoch += 1
        dev = self.ctx.device
        return b["input_ids"].to(dev, non_blocking=True), b["labels"].to(dev, non_blocking=True)

    def _autocast(self):
        if self.cfg.train.bf16 and self.ctx.device.type in ("cuda", "cpu"):
            return torch.autocast(self.ctx.device.type, dtype=torch.bfloat16)
        return contextlib.nullcontext()

    def _clip(self):
        tc, pc = self.cfg.train, self.cfg.parallel
        if self.off_opt is not None:
            return self.off_opt.clip_grad_norm_(tc.grad_clip)
        params = [p for p in self.model.parameters() if p.grad is not None]
        if not params:
            return torch.zeros(())
        grads = [p.grad for p in params]
        dt = [g for g in grads if hasattr(g, "to_local")]
        pl = [g for g in grads if not hasattr(g, "to_local")]
        dev = self.ctx.device
        sq = torch.zeros((), device=dev, dtype=torch.float32)
        if pl:
            sq = sq + torch.nn.utils.get_total_norm(pl).float().pow(2)
        meshes = {}
        for g in dt:                                  # DTensors: one norm per mesh (FSDP mesh vs TP mesh differ)
            meshes.setdefault(id(g.device_mesh), []).append(g)
        for lst in meshes.values():
            n = torch.nn.utils.get_total_norm(lst)
            sq = sq + (n.full_tensor() if hasattr(n, "full_tensor") else n).float().pow(2)
        norm = sq.sqrt()
        if pc.ep > 1 and self.ctx.world > 1:        # experts differ per ep rank -> their norm lives on other ranks
            e = [p.grad for n_, p in self.model.named_parameters() if ".experts." in n_ and p.grad is not None]
            ee = torch.nn.utils.get_total_norm(e).float().pow(2) if e else torch.zeros((), device=dev)
            dense = norm.pow(2) - ee
            dist.all_reduce(ee, group=self.ctx.ep_group)
            norm = (dense + ee).clamp(min=0).sqrt()
        if pc.pp > 1:
            sq = norm.pow(2)
            dist.all_reduce(sq, group=self.ctx.pp_group)
            norm = sq.sqrt()
        if tc.grad_clip and tc.grad_clip > 0:
            coef = float(min(1.0, tc.grad_clip / (float(norm) + 1e-6)))
            if coef < 1.0:
                for g in grads:
                    g.mul_(coef)
        return norm

    # ------------------------------------------------------------------------------------------------ one step
    def _fwd_bwd_micro(self, last: bool):
        accum = self.cfg.train.grad_accum
        ids, y = self._next_batch()
        if self.pp is not None:
            loss = self.pp.step(ids, y, last_sync=last)
            return loss if loss is not None else torch.zeros((), device=self.ctx.device)

        if self.is_fsdp:
            self.model.set_requires_gradient_sync(last)
        cm = self.model.no_sync() if (self.is_ddp and not last) else contextlib.nullcontext()
        with cm, self._autocast(), self.quant.autocast():
            ce, aux = self.model(ids, labels=y)
            loss = ce + aux
        if self.use_ds:
            self.engine.backward(loss)
        else:
            (loss / accum).backward()
        if self.off_opt is not None and (self.off_overlap or last):
            self.off_opt.collect()
        return ce.detach()

    def train_step(self):
        tc = self.cfg.train
        lr = self.lr_at(self.step)
        for g in self.opt.param_groups:
            g["lr"] = lr
        self.model.train()
        t0 = time.perf_counter()
        total = torch.zeros((), device=self.ctx.device)
        for m in range(tc.grad_accum):
            total += self._fwd_bwd_micro(m == tc.grad_accum - 1)
        loss = total / tc.grad_accum

        if self.use_ds:
            self.engine.step()
            gn = torch.tensor(float(self.engine.get_global_grad_norm() or 0.0))
            skip = False
        else:
            native.sync_expert_grads(self.model, self.ctx)
            gn = self._clip()
            ok = bool(torch.isfinite(gn)) if tc.skip_nonfinite else True
            if self.cfg.parallel.pp > 1 and self.ctx.world > 1:   # loss lives on the last stage only
                l = loss.clone(); dist.all_reduce(l, group=self.ctx.pp_group); loss = l
            lv = float(self.ctx.mean_over_dp(loss))
            if tc.skip_spike_factor > 0 and self.loss_ema is not None and lv > tc.skip_spike_factor * self.loss_ema:
                ok = False
            if self.ctx.world > 1:  # all ranks must agree to skip or ranks desync
                flag = torch.tensor(int(ok), device=self.ctx.device)
                dist.all_reduce(flag, op=dist.ReduceOp.MIN)
                ok = bool(flag.item())
            if ok:
                self.opt.step()
                self.loss_ema = lv if self.loss_ema is None else 0.98 * self.loss_ema + 0.02 * lv
            else:
                self.skipped += 1
            self.opt.zero_grad(set_to_none=True)
        lv = float(self.ctx.mean_over_dp(loss)) if not self.use_ds else float(loss)
        dt = time.perf_counter() - t0
        toks = self.micro_batch * (self.seq or 0) * tc.grad_accum * self.ctx.dp_world
        m = {"step": self.step + 1, "loss": lv, "lr": lr, "grad_norm": float(gn), "tok_s": toks / dt, "dt": dt,
             "skipped": self.skipped}
        if self.peak_flops and hasattr(self.raw, "flops_per_token") and self.seq:
            m["mfu"] = toks * self.raw.flops_per_token(self.seq) / dt / (self.peak_flops * self.ctx.world)
        if self.ctx.device.type == "cuda":
            m["mem_gb"] = torch.cuda.max_memory_allocated() / 2 ** 30
        self.step += 1
        return m

    @torch.no_grad()
    def evaluate(self):
        if self.eval_dl is None or self.cfg.parallel.pp > 1 or self.use_ds:
            return None
        self.model.eval()
        tot, n = torch.zeros((), device=self.ctx.device), 0
        for i, b in enumerate(self.eval_dl):
            if i >= self.cfg.train.eval_steps:
                break
            with self._autocast(), self.quant.autocast():
                ce, _ = self.model(b["input_ids"].to(self.ctx.device), labels=b["labels"].to(self.ctx.device))
            tot += ce.float(); n += 1
        self.model.train()
        return float(self.ctx.mean_over_dp(tot / max(n, 1)))

    # ------------------------------------------------------------------------------------------------ fit
    def fit(self):
        tc, ctx = self.cfg.train, self.ctx
        while self.step < tc.max_steps:
            m = self.train_step()
            self.history.append(m)
            if self.step % tc.log_every == 0 or self.step == 1:
                extra = f" mfu {m['mfu']*100:.1f}%" if "mfu" in m else ""
                extra += f" mem {m['mem_gb']:.1f}G" if "mem_gb" in m else ""
                log(ctx, f"step {m['step']:>6} | loss {m['loss']:.4f} | lr {m['lr']:.2e} | gnorm {m['grad_norm']:.2f} | "
                         f"{m['tok_s']:,.0f} tok/s | {m['dt']*1000:.0f} ms{extra}" + (f" | skipped {self.skipped}" if self.skipped else ""))
            if tc.eval_every and self.step % tc.eval_every == 0:
                ev = self.evaluate()
                if ev is not None:
                    log(ctx, f"step {self.step:>6} | eval loss {ev:.4f} | ppl {math.exp(min(ev, 20)):.2f}")
            for cb in self.callbacks:
                cb(self, m)
            if tc.ckpt_every and self.step % tc.ckpt_every == 0:
                self.save()
        if tc.ckpt_every:
            self.save()
        return self.history

    # ------------------------------------------------------------------------------------------------ checkpoint
    def _paths(self, step):
        root = self.cfg.train.ckpt_dir
        return root, os.path.join(root, f"step_{step:07d}")

    def _dcp_state(self):
        from torch.distributed.checkpoint.state_dict import get_state_dict
        opt = () if self.off_opt is not None or self.use_ds else self.opt
        return get_state_dict(self.model, opt)

    def save(self, keep_last: int = 3):
        import torch.distributed.checkpoint as dcp
        root, path = self._paths(self.step)
        os.makedirs(path, exist_ok=True)
        if self.use_ds:
            self.engine.save_checkpoint(root, tag=f"step_{self.step:07d}")
        else:
            msd, osd = self._dcp_state()
            state = {"model": msd}
            if self.off_opt is None:
                state["optim"] = osd
            dcp.save(state, checkpoint_id=os.path.join(path, "dcp"))
            if self.off_opt is not None:
                torch.save(self.off_opt.state_dict(), os.path.join(path, f"offopt_rank{self.ctx.rank}.pt"))
        meta = {"step": self.step, "epoch": self.epoch, "batches_in_epoch": self.batches_in_epoch,
                "loss_ema": self.loss_ema, "micro_batch": self.micro_batch}
        with open(os.path.join(path, f"meta_rank{self.ctx.rank}.json"), "w") as f:
            json.dump(meta, f)
        self.ctx.barrier()
        if self.ctx.rank == 0:
            with open(os.path.join(root, "latest"), "w") as f:
                f.write(os.path.basename(path))
            steps = sorted(d for d in os.listdir(root) if d.startswith("step_"))
            for d in steps[:-keep_last]:
                shutil.rmtree(os.path.join(root, d), ignore_errors=True)
        self.ctx.barrier()
        log(self.ctx, f"[forgemind] saved checkpoint {path}")

    def maybe_resume(self):
        import torch.distributed.checkpoint as dcp
        from torch.distributed.checkpoint.state_dict import set_state_dict
        root = self.cfg.train.ckpt_dir
        latest = os.path.join(root, "latest")
        if not os.path.exists(latest):
            return
        path = os.path.join(root, open(latest).read().strip())
        if self.use_ds:
            self.engine.load_checkpoint(root, tag=os.path.basename(path))
        else:
            msd, osd = self._dcp_state()
            state = {"model": msd}
            if self.off_opt is None:
                state["optim"] = osd
            dcp.load(state, checkpoint_id=os.path.join(path, "dcp"))
            set_state_dict(self.model, () if self.off_opt is not None else self.opt,
                           model_state_dict=state["model"], optim_state_dict=state.get("optim", {}))
            if self.off_opt is not None:
                self.off_opt.load_state_dict(torch.load(os.path.join(path, f"offopt_rank{self.ctx.rank}.pt")))
        meta = json.load(open(os.path.join(path, f"meta_rank{self.ctx.rank}.json")))
        self.step, self.loss_ema = meta["step"], meta["loss_ema"]
        self.epoch, self.sampler.epoch = meta["epoch"], meta["epoch"]
        self.sampler.skip = meta["batches_in_epoch"] * self.micro_batch
        self.batches_in_epoch = meta["batches_in_epoch"]
        self._it = iter(self.train_dl)
        log(self.ctx, f"[forgemind] resumed from {path} at step {self.step}")
