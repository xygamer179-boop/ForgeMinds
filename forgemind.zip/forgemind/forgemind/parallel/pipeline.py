"""Minimal, dependency-free pipeline-parallel runtime (GPipe + 1F1B) over point-to-point send/recv.
Static activation shape per microbatch; dtype/shape handshake happens once on the first step."""
from __future__ import annotations
import contextlib
import torch
import torch.distributed as dist

_DT = [torch.float32, torch.bfloat16, torch.float16]


class PipelineRunner:
    def __init__(self, model, ctx, loss_fn, n_microbatches, schedule="1f1b", fwd_ctx=contextlib.nullcontext):
        self.model, self.ctx, self.loss_fn, self.M = model, ctx, loss_fn, n_microbatches
        self.schedule, self.fwd_ctx = schedule, fwd_ctx
        self.s, self.S, self.g = ctx.pp_rank, ctx.pc.pp, ctx.pp_group
        self.first, self.last = self.s == 0, self.s == self.S - 1
        self.prev = dist.get_global_rank(self.g, self.s - 1) if not self.first else None
        self.next = dist.get_global_rank(self.g, self.s + 1) if not self.last else None
        self.meta = None        # (shape, dtype) of the activation arriving from the previous stage
        self.meta_sent = False

    # ---- p2p -------------------------------------------------------------------------------------------------------
    def _send_header(self, t):
        h = torch.zeros(8, dtype=torch.long, device=self.ctx.device)
        h[0], h[1] = t.ndim, _DT.index(t.dtype)
        h[2:2 + t.ndim] = torch.tensor(t.shape)
        dist.send(h, self.next, group=self.g)
        self.meta_sent = True

    def _recv_act(self):
        if self.meta is None:
            h = torch.zeros(8, dtype=torch.long, device=self.ctx.device)
            dist.recv(h, self.prev, group=self.g)
            self.meta = (tuple(h[2:2 + int(h[0])].tolist()), _DT[int(h[1])])
        buf = torch.empty(self.meta[0], dtype=self.meta[1], device=self.ctx.device)
        dist.recv(buf, self.prev, group=self.g)
        return buf

    # ---- one optimizer-step worth of microbatches --------------------------------------------------------------------
    def step(self, ids, y, last_sync=True):
        M = self.M
        xs, ys = ids.chunk(M), y.chunk(M)
        stash, keep, sends, losses = [], [], [], []
        sync_off = hasattr(self.model, "no_sync")
        fsdp = hasattr(self.model, "set_requires_gradient_sync") and not sync_off

        def fwd(i):
            if self.first:
                inp = xs[i]
            else:
                inp = self._recv_act().requires_grad_(True)
            with self.fwd_ctx():
                out = self.model(inp)
            if self.last:
                loss = self.loss_fn(out, ys[i])
                losses.append(loss.detach().float())
                stash.append((inp, loss / M))
            else:
                if not self.meta_sent:
                    self._send_header(out)
                o = out.detach().contiguous()
                keep.append(o)
                sends.append(dist.isend(o, self.next, group=self.g))
                stash.append((inp, out))

        def bwd(final):
            inp, out = stash.pop(0)
            if fsdp:
                self.model.set_requires_gradient_sync(final and last_sync)
            cm = self.model.no_sync() if (sync_off and not (final and last_sync)) else contextlib.nullcontext()
            with cm:
                if self.last:
                    out.backward()
                else:
                    g = torch.empty_like(out)
                    dist.recv(g, self.next, group=self.g)
                    out.backward(g)
            if not self.first:
                gi = inp.grad.contiguous()
                keep.append(gi)
                sends.append(dist.isend(gi, self.prev, group=self.g))

        if self.schedule == "gpipe":
            for i in range(M):
                fwd(i)
            for j in range(M):
                bwd(j == M - 1)
        else:  # 1F1B
            warm = min(M, self.S - self.s - 1)
            for i in range(warm):
                fwd(i)
            done = 0
            for i in range(M - warm):
                fwd(warm + i)
                bwd(done == M - 1); done += 1
            while done < M:
                bwd(done == M - 1); done += 1
        for w in sends:
            w.wait()
        return torch.stack(losses).mean() if self.last else None
