import functools
import torch
from torch.utils.checkpoint import checkpoint, create_selective_checkpoint_contexts, CheckpointPolicy

_SAVE = {torch.ops.aten.mm.default, torch.ops.aten.addmm.default, torch.ops.aten.bmm.default,
         torch.ops.aten._scaled_dot_product_flash_attention.default,
         torch.ops.aten._scaled_dot_product_efficient_attention.default,
         torch.ops.aten._scaled_dot_product_cudnn_attention.default}


def _policy(ctx, op, *a, **k):
    return CheckpointPolicy.MUST_SAVE if op in _SAVE else CheckpointPolicy.PREFER_RECOMPUTE


def apply_activation_checkpointing(model, mode="full"):
    """patches block.forward in place (FQNs unchanged). 'selective' keeps matmul/attention outputs, recomputes the rest."""
    for blk in model.layers.values():
        orig = blk.forward
        kw = dict(use_reentrant=False)
        if mode == "selective":
            kw["context_fn"] = functools.partial(create_selective_checkpoint_contexts, _policy)
        blk.forward = (lambda *a, _o=orig, _kw=kw, **k: checkpoint(_o, *a, **k, **_kw))
    return model
