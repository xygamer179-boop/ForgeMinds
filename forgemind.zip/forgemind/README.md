# ForgeMind
PyTorch training library: FSDP2/HSDP/DDP, tensor/pipeline/expert parallelism (3D), DeepSpeed ZeRO backend,
FP8 (Transformer Engine / torchao) and INT8 training, smart gradient/activation/expert offload, MoE, and a full trainer.

```bash
pip install -e .            # + torchao / transformer-engine / deepspeed as needed
torchrun --nproc_per_node=4 examples/train_gpt.py --moe --dp-replicate 4 --ep 2
torchrun --nproc_per_node=4 examples/train_gpt.py --tp 2 --dp-shard 2
python tests/test_single.py; python tests/test_ds_config.py
torchrun --standalone --nproc_per_node=2 tests/mp_check.py ep_equiv   # also tp_equiv, pp_equiv, ddp, fsdp, ...
```
Mesh: world = pp * dp_replicate * dp_shard * tp; `ep` divides the DP world.

## Status
Verified on CPU/gloo only (see tests). Untested: CUDA offload streams, TE/torchao FP8/INT8 training, DeepSpeed engine, NCCL.
Limits: EP+FSDP2 unsupported; MoE aux loss not propagated across PP stages; experts not TP'd or quantized;
OffloadedAdamW not for FSDP/PP; no eval under PP.
